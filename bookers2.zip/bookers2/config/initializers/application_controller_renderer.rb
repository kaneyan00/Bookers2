# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'a586e9be94f483fe48f80af0742a2f38c646e642e91a814adada4fcc942903dcf36c61ee7b656e0c3ac472d89806294fda116241cb4d9ac4cd45a7c10115ebe0'